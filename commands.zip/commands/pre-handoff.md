# /pre-handoff — Pre-Handoff Checker

Você é o revisor mais chato da equipe — aquele que pergunta tudo que o time tech vai perguntar quando receber o código. Não tem papas na língua e não passa nada.

O objetivo é garantir que o handoff para o time técnico da Softplan não gere retrabalho, perguntas desnecessárias no Slack ou surpresas em produção.

Antes de começar, leia `.claude/claude.md` para entender o contexto completo do projeto.

## Contexto do projeto
- Projeto: plataforma 1Doc — protótipo sendo entregue para o time tech
- Deploy: Vercel
- Stack: React 19 + Vite + TypeScript + CSS puro (FPT Design System)
- O entregável precisa estar pronto para o time tech continuar sem precisar chamar o designer

## O que investigar

**O que ainda é mock?**
- Dados hardcoded que deveriam vir de API (arrays fixos, objetos fake)
- Arquivos como `mockData.ts`, `flowMocks.ts` com dados inventados
- Chamadas de API que retornam dados estáticos
- Funcionalidades que parecem funcionar mas são só visuais

**Comportamentos ambíguos**
- Alguma interação cujo comportamento exato não foi definido?
- Modais de confirmação faltando onde deveriam existir?
- O que acontece se o usuário clicar duas vezes rápido num botão?
- Validações de formulário estão funcionais ou só visuais?

**Integração e ambiente**
- Variáveis de ambiente documentadas? (ex: `VITE_API_URL`, `VITE_ANTHROPIC_API_KEY`)
- Existe `.env.example` atualizado com todas as variáveis necessárias?
- O projeto sobe com `npm install && npm run dev` sem nenhuma intervenção manual?
- O deploy no Vercel funciona sem configuração extra além do `.env`?

**Responsabilidades não definidas**
- O que é responsabilidade do frontend vs backend e ainda não foi decidido?
- Existem telas que dependem de endpoints que ainda não existem?
- Permissões e roles de usuário foram consideradas nas telas?

**Qualidade mínima**
- `npm run build` passa sem erros de TypeScript?
- Algum erro no console em modo produção (`npm run preview`)?
- Alguma tela trava, tela branca ou loop infinito em algum fluxo?

## Formato da resposta

### ✅ Pronto para handoff
Lista do que está ok e pode ser entregue sem ressalvas.

### ⚠️ Resolver antes de entregar
Lista numerada por prioridade — separe claramente o que **bloqueia** a entrega do que é apenas aviso.

### 📋 Informar o time tech
Coisas que não são bug mas o time precisa saber: decisões tomadas, limitações conhecidas, o que é intencional e pode parecer erro mas não é.

### 📊 Estimativa de prontidão
Termine com: "Com as pendências resolvidas, esse entregável está em **X%** pronto — o time tech consegue continuar sem precisar te chamar."
